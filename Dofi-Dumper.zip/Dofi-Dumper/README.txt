                               Comment Installez Le Dumper - By Doflamingo 

- Pour installez le dumper il vous suffit d'installer (Python 3.12, Python 3.11, Python 3.10)
- Dans votre Microsoft Store. Et lancez Setup.bat une fois le chargement fini vous placez l'id
- du serveur Fivem dans Serveur.txt et faire lancez Start dump.bat

